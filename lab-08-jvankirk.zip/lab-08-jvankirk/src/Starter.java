import javax.swing.*;
import java.awt.*;

public class Starter {
//	Create a paint program. It should look similar to the picture below. When the user
//	clicks on a brush at the top it changes the current shape. When the user clicks on a
//	color it changes the color of the current brush. When the user clicks Erase all of the
//	objects are erased. The user draws by dragging their mouse in the paint area. The
//	current brush is displayed on the bottom right
	public static void main (String [] args) {	
		//Frame
		JFrame paintFrame = new JFrame("Paint");
		paintFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//Drawing Panel(Area inside the Frame)
		DrawingPanel backgroundPanel = new DrawingPanel();
		backgroundPanel.setPreferredSize(new Dimension(830,620));
		backgroundPanel.setBackground(Color.gray);
		//Connecting the Panel and Frame.
		paintFrame.getContentPane().add(backgroundPanel);
		paintFrame.pack();
		//This ridiculous phrase.
		paintFrame.setVisible(true);
	}
//I'm sure there is a better way to organize drawing panel, but I believe I do not have enough time
//to reorganize it.
}
