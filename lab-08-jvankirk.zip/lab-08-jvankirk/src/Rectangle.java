
import java.awt.*;
import java.awt.Color;

public class Rectangle implements PaintBrushes{
	protected int x;
	protected int y;
	protected int width;
	protected int height;
	protected Color color;
	
	
	public Rectangle(int x, int y, int width, int height, Color color) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.color = color;
	}
	public void setColor(Color color) {
		this.color = color;
	}
	
	public void rectanglePaint(Graphics g) {
		g.setColor(color);
        g.fillRect(x, y, width, height);
	}
	public void paint(Graphics g) {
		g.setColor(color);
        g.fillRect(x, y, width, height);
	}
}
