import java.awt.Color;
import java.util.ArrayList;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.*;

public class DrawingPanel extends JPanel implements ActionListener, MouseListener, MouseMotionListener{
	//Sections
	Rectangle canvas;
	Rectangle palette;
	//Colors
	Rectangle [][] colorPlaceHolders = new Rectangle [4][4];
	Rectangle blackPH;
	Rectangle grayPH;
	Rectangle lGPH;
	Rectangle gPH;
	Rectangle lYPH;
	Rectangle yPH;
	Rectangle lOPH;
	Rectangle oPH;
	Rectangle lRPH;
	Rectangle rPH;
	Rectangle lPPH;
	Rectangle pPH;
	Rectangle lPuPH;
	Rectangle puPH;
	Rectangle lBPH;
	Rectangle bPH;
	//I wish I could put these somewhere else, but an enum would not work, and a class does not make sense.
	//At least, to me it doesn't make sense.
	Color black = new Color(0,0,0,255);
	Color gray = new Color(128,123,124,255);
	Color lightGreen = new Color(173,255,170,255);
	Color green = new Color(58,115,76,255);
	Color lightYellow = new Color(248,255,155,255);
	Color yellow = new Color(255,242,11,255);
	Color lightOrange = new Color(255,224,160,255);
	Color orange = new Color(214,145,49,255);
	Color lightRed = new Color(255,122,125,255);
	Color red = new Color(200,92,83);
	Color lightPink = new Color(255,196,210,255);
	Color pink = new Color(255,180,241,255);
	Color lightPurple = new Color(230,209,255,255);
	Color purple = new Color(151,91,255,255);
	Color lightBlue = new Color(193,255,255,255);
	Color blue = new Color(48,68,202,255);
	Color transparent = new Color(1,1,1,0);
	//Brushes
	Rectangle smallRectanglePH;
	Rectangle smallRectangle;
	Rectangle meduimRectanglePH;
	Rectangle meduimRectangle;
	Rectangle largeRectanglePH;
	Rectangle largeRectangle;
	Circle smallCirclePH;
	Circle smallCircle;
	Circle meduimCirclePH;
	Circle meduimCircle;
	Circle largeCirclePH;
	Circle largeCircle;
	//Erase Button
	Rectangle eraseButton;
	//Current Brush
	Rectangle currentBrushHolder;
	//The Actual Painting
	Color clickedColor;
	Color currentRectangleColor;
	Color currentCircleColor;
	int x;
	int y;
	int currentSize;
	Rectangle currentRectangleBrush;
	Circle currentCircleBrush;
	final int rectangle = 0;
	final int circle = 1;
	int circleOrRectangle;
	ArrayList<PaintBrushes> paintBrush = new ArrayList<>();

	public void shapeChange() {
		currentBrushHolder = new Rectangle(680,515,80,80,Color.lightGray);
		if (currentSize == 20) {
			currentRectangleBrush = new Rectangle (710,545,20,20,currentRectangleColor);
		} else if (currentSize == 35) {
			currentRectangleBrush = new Rectangle (702,537,36,36,currentRectangleColor);
		} else if (currentSize == 55) {
			currentRectangleBrush = new Rectangle (692,527,56,56,currentRectangleColor);
		}
		if (currentSize == 20) {
			currentCircleBrush = new Circle (710,545,20,20,currentCircleColor);
		} else if (currentSize == 35) {
			currentCircleBrush = new Circle (702,537,36,36,currentCircleColor);
		} else if (currentSize == 55) {
			currentCircleBrush = new Circle (692,527,56,56,currentCircleColor);
		}
		repaint();
	}

	public DrawingPanel () {
		super();
		//Sections
		canvas = new Rectangle(10,10,600,600, Color.white);
		palette = new Rectangle(620,10,200,600, Color.white);
		//Colors
		int yPlacement = 25;
		for(int counter = 0; counter < colorPlaceHolders.length; counter ++) {
			int xPlacement = 635;
			for(int counter2 = 0; counter2 < colorPlaceHolders[counter].length; counter2 ++) {
				colorPlaceHolders[counter][counter2] = new Rectangle(xPlacement, yPlacement, 35,35, Color.lightGray);
				xPlacement +=45;
			}
			yPlacement += 50;
			xPlacement = 635;
		}
		blackPH = new Rectangle (640,30,25,25,black);
		grayPH = new Rectangle(685,30,25,25,gray);
		lGPH = new Rectangle(730,30,25,25,lightGreen);
		gPH = new Rectangle(775,30,25,25,green);
		lYPH = new Rectangle(640,80,25,25,lightYellow);
		yPH = new Rectangle(685,80,25,25,yellow);
		lOPH = new Rectangle(730,80,25,25,lightOrange);
		oPH = new Rectangle(775,80,25,25,orange);
		lRPH = new Rectangle(640,130,25,25,lightRed);
		rPH = new Rectangle(685,130,25,25,red);
		lPPH = new Rectangle(730,130,25,25,lightPink);
		pPH = new Rectangle(775,130,25,25,pink);
		lPuPH = new Rectangle(640,180,25,25,lightPurple);
		puPH = new Rectangle(685,180,25,25,purple);
		lBPH = new Rectangle(730,180,25,25,lightBlue);
		bPH = new Rectangle(775,180,25,25,blue);
		//Brushes
		smallRectanglePH = new Rectangle(635,265,30,30,Color.lightGray);
		meduimRectanglePH = new Rectangle(680,258,45,45,Color.lightGray);
		largeRectanglePH = new Rectangle(740,247,65,65,Color.lightGray);
		smallRectangle = new Rectangle(640,270,20,20,Color.white);
		meduimRectangle = new Rectangle(685,263,35,35,Color.white);
		largeRectangle = new Rectangle(745,252,55,55,Color.white);
		smallCirclePH = new Circle(635,365,30,30,Color.lightGray);
		meduimCirclePH = new Circle(680,358,45,45,Color.lightGray);
		largeCirclePH = new Circle(740,347,65,65,Color.lightGray);
		smallCircle = new Circle(640,370,20,20,Color.white);
		meduimCircle = new Circle(685,363,35,35,Color.white);
		largeCircle = new Circle(745,352,55,55,Color.white);
		//Erase Button
		eraseButton = new Rectangle(640,425,160,60,Color.lightGray);
		//Current Brush Holder
		currentBrushHolder = new Rectangle(680,515,80,80,Color.lightGray);
		//The Actual Painting
		currentSize = 35;
		circleOrRectangle = 0;
		clickedColor = black;
		currentRectangleColor = black;
		currentCircleColor = transparent;
		shapeChange();
		Timer t = new Timer(10,this);
		t.start();
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
	}

	public void paintComponent(Graphics g) {
		//Sections
		canvas.rectanglePaint(g);
		palette.rectanglePaint(g);
		//Colors
		for(int counter = 0; counter < colorPlaceHolders.length; counter ++) {
			for(int counter2 = 0; counter2 < colorPlaceHolders[counter].length; counter2 ++) {
				colorPlaceHolders[counter][counter2].rectanglePaint(g);
			}
		}
		blackPH.rectanglePaint(g);
		grayPH.rectanglePaint(g);
		lGPH.rectanglePaint(g);
		gPH.rectanglePaint(g);
		lYPH.rectanglePaint(g);
		yPH.rectanglePaint(g);
		lOPH.rectanglePaint(g);
		oPH.rectanglePaint(g);
		lRPH.rectanglePaint(g);
		rPH.rectanglePaint(g);
		lPPH.rectanglePaint(g);
		pPH.rectanglePaint(g);
		lPuPH.rectanglePaint(g);
		puPH.rectanglePaint(g);
		lBPH.rectanglePaint(g);
		bPH.rectanglePaint(g);
		//Brushes
		smallRectanglePH.rectanglePaint(g);
		meduimRectanglePH.rectanglePaint(g);
		largeRectanglePH.rectanglePaint(g);
		smallRectangle.rectanglePaint(g);
		meduimRectangle.rectanglePaint(g);
		largeRectangle.rectanglePaint(g);
		smallCirclePH.circlePaint(g);
		meduimCirclePH.circlePaint(g);
		largeCirclePH.circlePaint(g);
		smallCircle.circlePaint(g);
		meduimCircle.circlePaint(g);
		largeCircle.circlePaint(g);
		//Erase Button
		eraseButton.rectanglePaint(g);
		g.setColor(Color.black);
		g.drawString("Erase",703,460);
		//Current Brush
		currentBrushHolder.rectanglePaint(g);
		currentRectangleBrush.rectanglePaint(g);
		currentCircleBrush.circlePaint(g);

		for (int counter = 0; counter < paintBrush.size(); counter++) {
			paintBrush.get(counter).paint(g);
		}
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		canvas = new Rectangle(10,10,600,600, Color.white);
		//Painting on the Canvas
		x = e.getX();
		y = e.getY();
		if(x >= 20 && x <= 600 && y >= 20 && y<= 600 && circleOrRectangle == rectangle && currentSize == 20) {
			Rectangle paintBrushNumber = new Rectangle(x-10,y-10,20,20,clickedColor);
			paintBrush.add(paintBrushNumber);
			repaint();
		}else if(x >= 27 && x <= 593 && y >= 27 && y<= 593 && circleOrRectangle == rectangle && currentSize == 35) {
			Rectangle paintBrushNumber = new Rectangle(x-17,y-17,35,35,clickedColor);
			paintBrush.add(paintBrushNumber);
			repaint();
		}else if(x >= 37 && x <= 583 && y >= 37 && y<= 583 && circleOrRectangle == rectangle && currentSize == 55) {
			Rectangle paintBrushNumber = new Rectangle(x-27,y-27,55,55,clickedColor);
			paintBrush.add(paintBrushNumber);
			repaint();
		}
		if(x >= 20 && x <= 600 && y >= 20 && y<= 600 && circleOrRectangle == circle && currentSize == 20) {
			Circle paintBrushNumber = new Circle(x-10,y-10,20,20,clickedColor);
			paintBrush.add(paintBrushNumber);
			repaint();
		}else if(x >= 27 && x <= 593 && y >= 27 && y<= 593 && circleOrRectangle == circle && currentSize == 35) {
			Circle paintBrushNumber = new Circle(x-17,y-17,35,35,clickedColor);
			paintBrush.add(paintBrushNumber);
			repaint();
		}else if(x >= 37 && x <= 583 && y >= 37 && y<= 583 && circleOrRectangle == circle && currentSize == 55) {
			Circle paintBrushNumber = new Circle(x-27,y-27,55,55,clickedColor);
			paintBrush.add(paintBrushNumber);
			repaint();
		}
	}


	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseClicked(MouseEvent e) {
		x = e.getX();
		y = e.getY();
		//Rectangle Brush Click
		if(x >= 640 && x <= 660 && y >= 270 && y<= 290) {
			currentSize = 20;
			currentRectangleColor = clickedColor;
			currentCircleColor = transparent;
			shapeChange();
			circleOrRectangle = rectangle;
		}else if(x >= 685 && x <= 720 && y >= 263 && y<= 298) {
			currentSize = 35;
			currentRectangleColor = clickedColor;
			currentCircleColor = transparent;
			shapeChange();
			circleOrRectangle = rectangle;
		}else if(x >= 745 && x <= 800 && y >= 252 && y<= 307) {
			currentSize = 55;
			currentRectangleColor = clickedColor;
			currentCircleColor = transparent;
			shapeChange();
			circleOrRectangle = rectangle;
		}
		//Circle Brush Click
		if(x >= 640 && x <= 660 && y >= 370 && y<= 390) {
			currentSize = 20;
			currentCircleColor = clickedColor;
			currentRectangleColor = transparent;
			shapeChange();
			circleOrRectangle = circle;
		}else if(x >= 685 && x <= 720 && y >= 363 && y<= 398) {
			currentSize = 35;
			currentCircleColor = clickedColor;
			currentRectangleColor = transparent;
			shapeChange();
			circleOrRectangle = circle;
		}else if(x >= 745 && x <= 800 && y >= 352 && y<= 407) {
			currentSize = 55;
			currentCircleColor = clickedColor;
			currentRectangleColor = transparent;
			shapeChange();
			circleOrRectangle = circle;
		}
		//Color Changes
		//Row 1
		if(x >= 640 && x <= 665 && y >= 30 && y<= 55) {
			clickedColor = black;
			if (circleOrRectangle == rectangle) {
				currentRectangleColor = clickedColor;
			} else if(circleOrRectangle == circle) {
				currentCircleColor = clickedColor;
			}
			shapeChange();
		}else if(x >= 685 && x <= 710 && y >= 30 && y<= 55) {
			clickedColor = gray;
			if (circleOrRectangle == rectangle) {
				currentRectangleColor = clickedColor;
			} else if(circleOrRectangle == circle) {
				currentCircleColor = clickedColor;
			}
			shapeChange();
		}else if(x >= 730 && x <= 755 && y >= 30 && y<= 55) {
			clickedColor = lightGreen;
			if (circleOrRectangle == rectangle) {
				currentRectangleColor = clickedColor;
			} else if(circleOrRectangle == circle) {
				currentCircleColor = clickedColor;
			}
			shapeChange();
		}else if(x >= 775 && x <= 800 && y >= 30 && y<= 55) {
			clickedColor = green;
			if (circleOrRectangle == rectangle) {
				currentRectangleColor = clickedColor;
			} else if(circleOrRectangle == circle) {
				currentCircleColor = clickedColor;
			}
			shapeChange();
		}
		//Row 2
		if(x >= 640 && x <= 665 && y >= 80 && y<= 105) {
			clickedColor = lightYellow;
			if (circleOrRectangle == rectangle) {
				currentRectangleColor = clickedColor;
			} else if(circleOrRectangle == circle) {
				currentCircleColor = clickedColor;
			}
			shapeChange();
		}else if(x >= 685 && x <= 710 && y >= 80 && y<= 105) {
			clickedColor = yellow;
			if (circleOrRectangle == rectangle) {
				currentRectangleColor = clickedColor;
			} else if(circleOrRectangle == circle) {
				currentCircleColor = clickedColor;
			}
			shapeChange();
		}else if(x >= 730 && x <= 755 && y >= 80 && y<= 105) {
			clickedColor = lightOrange;
			if (circleOrRectangle == rectangle) {
				currentRectangleColor = clickedColor;
			} else if(circleOrRectangle == circle) {
				currentCircleColor = clickedColor;
			}
			shapeChange();
		}else if(x >= 775 && x <= 800 && y >= 80 && y<= 105) {
			clickedColor = orange;
			if (circleOrRectangle == rectangle) {
				currentRectangleColor = clickedColor;
			} else if(circleOrRectangle == circle) {
				currentCircleColor = clickedColor;
			}
			shapeChange();
		}
		//Row 3
		if(x >= 640 && x <= 665 && y >= 130 && y<= 155) {
			clickedColor = lightRed;
			if (circleOrRectangle == rectangle) {
				currentRectangleColor = clickedColor;
			} else if(circleOrRectangle == circle) {
				currentCircleColor = clickedColor;
			}
			shapeChange();
		}else if(x >= 685 && x <= 710 && y >= 130 && y<= 155) {
			clickedColor = red;
			if (circleOrRectangle == rectangle) {
				currentRectangleColor = clickedColor;
			} else if(circleOrRectangle == circle) {
				currentCircleColor = clickedColor;
			}
			shapeChange();
		}else if(x >= 730 && x <= 755 && y >= 130 && y<= 155) {
			clickedColor = lightPink;
			if (circleOrRectangle == rectangle) {
				currentRectangleColor = clickedColor;
			} else if(circleOrRectangle == circle) {
				currentCircleColor = clickedColor;
			}
			shapeChange();
		}else if(x >= 775 && x <= 800 && y >= 130 && y<= 155) {
			clickedColor = pink;
			if (circleOrRectangle == rectangle) {
				currentRectangleColor = clickedColor;
			} else if(circleOrRectangle == circle) {
				currentCircleColor = clickedColor;
			}
			shapeChange();
		}
		//Row 4
		if(x >= 640 && x <= 665 && y >= 180 && y<= 205) {
			clickedColor = lightPurple;
			if (circleOrRectangle == rectangle) {
				currentRectangleColor = clickedColor;
			} else if(circleOrRectangle == circle) {
				currentCircleColor = clickedColor;
			}
			shapeChange();
		}else if(x >= 685 && x <= 710 && y >= 180 && y<= 205) {
			clickedColor = purple;
			if (circleOrRectangle == rectangle) {
				currentRectangleColor = clickedColor;
			} else if(circleOrRectangle == circle) {
				currentCircleColor = clickedColor;
			}
			shapeChange();
		}else if(x >= 730 && x <= 755 && y >= 180 && y<= 205) {
			clickedColor = lightBlue;
			if (circleOrRectangle == rectangle) {
				currentRectangleColor = clickedColor;
			} else if(circleOrRectangle == circle) {
				currentCircleColor = clickedColor;
			}
			shapeChange();
		}else if(x >= 775 && x <= 800 && y >= 180 && y<= 205) {
			clickedColor = blue;
			if (circleOrRectangle == rectangle) {
				currentRectangleColor = clickedColor;
			} else if(circleOrRectangle == circle) {
				currentCircleColor = clickedColor;
			}
			shapeChange();
		}
		//Erase
		if (x >= 640 && x <= 800 && y >= 425 && y<= 485) {
			for (int counter = 0; counter < paintBrush.size(); counter++) {
				paintBrush.get(counter).setColor(transparent);
			}
			repaint();
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void actionPerformed(ActionEvent e) {
		this.repaint();

	}
}
